#!/usr/bin/env node
/**
 * MemorAI Advanced MCP Server - Phase 1.2
 * Microsoft MCP-Compliant Architecture Implementation
 * 
 * Features:
 * - 15+ Advanced MCP Tools 
 * - Microsoft MCP best practices
 * - Multi-transport support (stdio, HTTP/SSE, WebSocket)
 * - Comprehensive error handling and logging
 * - Enterprise-grade validation and monitoring
 * - CBD integration with performance optimization
 */

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
    CallToolRequestSchema,
    ErrorCode,
    ListToolsRequestSchema,
    McpError,
    Tool,
    CallToolResult
} from '@modelcontextprotocol/sdk/types.js';
import { CBDMemoryEngine } from '@codai/cbd';
import type { CBDMemoryEngine as CBDMemoryEngineType } from '@codai/cbd';
import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
import { v4 as uuidv4 } from 'uuid';
import { z } from 'zod';

/**
 * Transport types supported by the advanced server
 */
export type TransportType = 'stdio' | 'http' | 'websocket';

/**
 * Advanced server configuration with comprehensive options
 */
interface AdvancedMemorAIMCPConfig {
    server: {
        name: string;
        version: string;
        description: string;
        authors: string[];
        homepage: string;
        license: string;
    };
    transport: {
        primary: TransportType;
        fallback: TransportType[];
        http?: {
            port: number;
            host: string;
            apiKey: string;
            cors: {
                origin: string | string[];
                credentials: boolean;
            };
        };
        websocket?: {
            port: number;
            path: string;
        };
    };
    cbd: {
        dataPath: string;
        embeddingModel: 'openai' | 'local';
        apiKey?: string;
        dimensions: number;
        cacheSize: number;
        performance: {
            maxConcurrency: number;
            timeout: number;
            retryAttempts: number;
        };
    };
    logging: {
        enabled: boolean;
        level: 'error' | 'warn' | 'info' | 'debug';
        structured: boolean;
        output: 'console' | 'file' | 'both';
        filePath?: string;
    };
    monitoring: {
        enabled: boolean;
        metricsInterval: number;
        healthCheck: {
            enabled: boolean;
            interval: number;
        };
    };
    security: {
        validateInputs: boolean;
        sanitizeOutputs: boolean;
        rateLimiting: {
            enabled: boolean;
            maxRequests: number;
            windowMs: number;
        };
    };
}

/**
 * Operation result with comprehensive metadata
 */
interface AdvancedOperationResult {
    success: boolean;
    data?: any;
    error?: string;
    metadata: {
        operation: string;
        timestamp: string;
        responseTimeMs: number;
        serverVersion: string;
        requestId: string;
        performanceMetrics?: {
            cpuUsage: number;
            memoryUsage: number;
            operationCount: number;
        };
    };
}

/**
 * Advanced MemorAI MCP Server - Phase 1.2
 * Implements Microsoft MCP best practices with enterprise-grade features
 */
export class AdvancedMemorAIMCPServer {
    private server: Server;
    private cbdEngine: CBDMemoryEngineType;
    private config: AdvancedMemorAIMCPConfig;
    private initialized = false;
    private operationCount = 0;
    private startTime = Date.now();
    private requestMetrics = new Map<string, number>();
    private expressApp?: express.Application;
    private httpServer?: import('http').Server;
    private socketServer?: SocketIOServer;

    // Advanced tool definitions following Microsoft MCP specifications
    private readonly advancedTools: Tool[] = [
        // Core Memory Operations (4 tools)
        {
            name: 'remember',
            description: 'Enhanced semantic storage with metadata and embeddings',
            inputSchema: {
                type: 'object',
                properties: {
                    agentId: {
                        type: 'string',
                        description: 'Agent identifier for memory isolation',
                        pattern: '^[a-zA-Z0-9_-]+$'
                    },
                    content: {
                        type: 'string',
                        description: 'Memory content to store',
                        minLength: 1,
                        maxLength: 100000
                    },
                    metadata: {
                        type: 'object',
                        description: 'Enhanced metadata with validation',
                        properties: {
                            entityType: { type: 'string', enum: ['task', 'knowledge', 'context', 'decision', 'insight'] },
                            priority: { type: 'string', enum: ['low', 'medium', 'high', 'critical'] },
                            project: { type: 'string', pattern: '^[a-zA-Z0-9_-]+$' },
                            session: { type: 'string', pattern: '^[a-zA-Z0-9_-]+$' },
                            tags: { type: 'array', items: { type: 'string' }, maxItems: 10 },
                            expiresAt: { type: 'string', format: 'date-time' },
                            confidenceScore: { type: 'number', minimum: 0, maximum: 1 }
                        }
                    }
                },
                required: ['agentId', 'content']
            }
        },
        {
            name: 'recall',
            description: 'Advanced search with fuzzy matching, ranking, and context',
            inputSchema: {
                type: 'object',
                properties: {
                    agentId: { type: 'string', description: 'Agent identifier (use "all" for cross-agent search)' },
                    query: { type: 'string', description: 'Natural language search query', minLength: 1 },
                    limit: { type: 'number', minimum: 1, maximum: 100, default: 10 },
                    minImportance: { type: 'number', minimum: 0, maximum: 1, default: 0 },
                    contextSize: { type: 'number', minimum: 1, maximum: 20, default: 5 },
                    fuzzyMatch: { type: 'boolean', default: true },
                    includeMetadata: { type: 'boolean', default: true },
                    sortBy: { type: 'string', enum: ['relevance', 'recency', 'importance'], default: 'relevance' },
                    filters: {
                        type: 'object',
                        properties: {
                            entityType: { type: 'string' },
                            priority: { type: 'string' },
                            project: { type: 'string' },
                            session: { type: 'string' },
                            tags: { type: 'array', items: { type: 'string' } },
                            dateRange: {
                                type: 'object',
                                properties: {
                                    from: { type: 'string', format: 'date-time' },
                                    to: { type: 'string', format: 'date-time' }
                                }
                            }
                        }
                    }
                },
                required: ['agentId', 'query']
            }
        },
        {
            name: 'forget',
            description: 'Smart deletion with dependency checking and cascade options',
            inputSchema: {
                type: 'object',
                properties: {
                    agentId: { type: 'string', description: 'Agent identifier' },
                    structuredKey: { type: 'string', description: 'Memory key to delete' },
                    cascade: { type: 'boolean', default: false, description: 'Delete related memories' },
                    confirm: { type: 'boolean', default: false, description: 'Confirmation required for deletion' }
                },
                required: ['agentId', 'structuredKey']
            }
        },
        {
            name: 'context',
            description: 'Intelligent context synthesis from multiple related memories',
            inputSchema: {
                type: 'object',
                properties: {
                    agentId: { type: 'string', description: 'Agent identifier' },
                    contextSize: { type: 'number', minimum: 1, maximum: 50, default: 5 },
                    synthesize: { type: 'boolean', default: true, description: 'Generate context summary' },
                    includeRelated: { type: 'boolean', default: true },
                    timeWindow: { type: 'string', enum: ['hour', 'day', 'week', 'month', 'all'], default: 'day' }
                },
                required: ['agentId']
            }
        },

        // Intelligence & Analysis (4 tools)
        {
            name: 'analyze_patterns',
            description: 'Discover relationships, trends, and insights in memory data',
            inputSchema: {
                type: 'object',
                properties: {
                    agentId: { type: 'string' },
                    analysisType: { type: 'string', enum: ['relationships', 'trends', 'clusters', 'anomalies', 'all'], default: 'all' },
                    timeRange: { type: 'string', enum: ['day', 'week', 'month', 'quarter', 'year'], default: 'month' },
                    minPatternStrength: { type: 'number', minimum: 0, maximum: 1, default: 0.5 }
                },
                required: ['agentId']
            }
        },
        {
            name: 'memory_graph',
            description: 'Generate and visualize memory connections and clusters',
            inputSchema: {
                type: 'object',
                properties: {
                    agentId: { type: 'string' },
                    maxNodes: { type: 'number', minimum: 10, maximum: 1000, default: 100 },
                    includeWeights: { type: 'boolean', default: true },
                    layout: { type: 'string', enum: ['force', 'hierarchical', 'circular'], default: 'force' }
                },
                required: ['agentId']
            }
        },
        {
            name: 'temporal_search',
            description: 'Time-based queries, evolution tracking, and historical analysis',
            inputSchema: {
                type: 'object',
                properties: {
                    agentId: { type: 'string' },
                    query: { type: 'string' },
                    timeRange: {
                        type: 'object',
                        properties: {
                            from: { type: 'string', format: 'date-time' },
                            to: { type: 'string', format: 'date-time' }
                        },
                        required: ['from', 'to']
                    },
                    evolutionTracking: { type: 'boolean', default: true }
                },
                required: ['agentId', 'timeRange']
            }
        },
        {
            name: 'semantic_clustering',
            description: 'Automatic memory organization by topic and similarity',
            inputSchema: {
                type: 'object',
                properties: {
                    agentId: { type: 'string' },
                    clusterCount: { type: 'number', minimum: 2, maximum: 50, default: 10 },
                    similarityThreshold: { type: 'number', minimum: 0, maximum: 1, default: 0.7 },
                    autoLabel: { type: 'boolean', default: true }
                },
                required: ['agentId']
            }
        },

        // Collaboration & Sharing (3 tools)
        {
            name: 'collaborative_memory',
            description: 'Share and synchronize memories across agents and users',
            inputSchema: {
                type: 'object',
                properties: {
                    sourceAgentId: { type: 'string' },
                    targetAgentId: { type: 'string' },
                    memoryKey: { type: 'string' },
                    permissions: { type: 'string', enum: ['read', 'write', 'admin'], default: 'read' },
                    expiresAt: { type: 'string', format: 'date-time' }
                },
                required: ['sourceAgentId', 'targetAgentId', 'memoryKey']
            }
        },
        {
            name: 'cross_reference',
            description: 'Find related memories across different contexts and projects',
            inputSchema: {
                type: 'object',
                properties: {
                    query: { type: 'string' },
                    agentIds: { type: 'array', items: { type: 'string' }, maxItems: 10 },
                    projects: { type: 'array', items: { type: 'string' }, maxItems: 10 },
                    similarityThreshold: { type: 'number', minimum: 0, maximum: 1, default: 0.6 }
                },
                required: ['query']
            }
        },
        {
            name: 'memory_insights',
            description: 'Generate summaries, knowledge extraction, and reports',
            inputSchema: {
                type: 'object',
                properties: {
                    agentId: { type: 'string' },
                    insightType: { type: 'string', enum: ['summary', 'knowledge_map', 'activity_report', 'trends'], default: 'summary' },
                    timeRange: { type: 'string', enum: ['day', 'week', 'month'], default: 'week' },
                    format: { type: 'string', enum: ['text', 'json', 'markdown'], default: 'markdown' }
                },
                required: ['agentId']
            }
        },

        // Management & Maintenance (4 tools)
        {
            name: 'memory_analytics',
            description: 'Performance metrics, usage insights, and optimization recommendations',
            inputSchema: {
                type: 'object',
                properties: {
                    agentId: { type: 'string' },
                    metricsType: { type: 'string', enum: ['usage', 'performance', 'quality', 'all'], default: 'all' },
                    includeRecommendations: { type: 'boolean', default: true }
                },
                required: ['agentId']
            }
        },
        {
            name: 'smart_suggestions',
            description: 'AI-powered memory recommendations and auto-completion',
            inputSchema: {
                type: 'object',
                properties: {
                    agentId: { type: 'string' },
                    query: { type: 'string' },
                    suggestionType: { type: 'string', enum: ['queries', 'content', 'tags', 'projects'], default: 'queries' },
                    limit: { type: 'number', minimum: 1, maximum: 20, default: 5 }
                },
                required: ['agentId', 'query']
            }
        },
        {
            name: 'memory_backup',
            description: 'Export/import with versioning, compression, and encryption',
            inputSchema: {
                type: 'object',
                properties: {
                    operation: { type: 'string', enum: ['export', 'import'], required: true },
                    agentId: { type: 'string' },
                    format: { type: 'string', enum: ['json', 'cbor', 'msgpack'], default: 'json' },
                    compression: { type: 'boolean', default: true },
                    encryption: { type: 'boolean', default: false },
                    filePath: { type: 'string' }
                },
                required: ['operation', 'agentId']
            }
        },
        {
            name: 'memory_cleanup',
            description: 'Automated maintenance, deduplication, and optimization',
            inputSchema: {
                type: 'object',
                properties: {
                    agentId: { type: 'string' },
                    operations: {
                        type: 'array',
                        items: { type: 'string', enum: ['deduplicate', 'expire_old', 'optimize_index', 'compress'] },
                        default: ['deduplicate', 'expire_old']
                    },
                    dryRun: { type: 'boolean', default: true }
                },
                required: ['agentId']
            }
        },

        // Enterprise Features (2 tools)
        {
            name: 'memory_security',
            description: 'Access control, encryption, and audit trails',
            inputSchema: {
                type: 'object',
                properties: {
                    operation: { type: 'string', enum: ['audit', 'permissions', 'encrypt', 'decrypt'] },
                    agentId: { type: 'string' },
                    targetResource: { type: 'string' },
                    permissions: {
                        type: 'object',
                        properties: {
                            read: { type: 'boolean' },
                            write: { type: 'boolean' },
                            delete: { type: 'boolean' },
                            admin: { type: 'boolean' }
                        }
                    }
                },
                required: ['operation', 'agentId']
            }
        },
        {
            name: 'memory_monitoring',
            description: 'Real-time health checks, alerts, and diagnostics',
            inputSchema: {
                type: 'object',
                properties: {
                    checkType: { type: 'string', enum: ['health', 'performance', 'capacity', 'all'], default: 'health' },
                    includeMetrics: { type: 'boolean', default: true },
                    generateReport: { type: 'boolean', default: false }
                }
            }
        }
    ];

    constructor(config?: Partial<AdvancedMemorAIMCPConfig>) {
        this.config = this.mergeConfig(config);
        this.server = this.initializeServer();
        this.cbdEngine = this.initializeCBDEngine();
        this.setupRequestHandlers();
        this.initializeMonitoring();
    }

    /**
     * Merge user configuration with defaults
     */
    private mergeConfig(userConfig?: Partial<AdvancedMemorAIMCPConfig>): AdvancedMemorAIMCPConfig {
        const defaultConfig: AdvancedMemorAIMCPConfig = {
            server: {
                name: 'MemorAI Advanced MCP Server',
                version: '9.7.0-advanced',
                description: 'Advanced Memory Management with CBD Integration',
                authors: ['CODAI Team'],
                homepage: 'https://github.com/codai-ecosystem/codai-project',
                license: 'MIT'
            },
            transport: {
                primary: 'stdio',
                fallback: ['http'],
                http: {
                    port: parseInt(process.env.MEMORAI_MCP_PORT || '4950'),
                    host: '0.0.0.0',
                    apiKey: process.env.MEMORAI_API_KEY || 'memorai-dev-key-2025',
                    cors: {
                        origin: '*',
                        credentials: true
                    }
                }
            },
            cbd: {
                dataPath: process.env.MEMORAI_CBD_PATH || './memorai-cbd-data',
                embeddingModel: 'openai',
                apiKey: process.env.OPENAI_API_KEY,
                dimensions: 1536,
                cacheSize: 10000,
                performance: {
                    maxConcurrency: 10,
                    timeout: 30000,
                    retryAttempts: 3
                }
            },
            logging: {
                enabled: true,
                level: (process.env.MEMORAI_LOG_LEVEL as any) || 'info',
                structured: true,
                output: 'console'
            },
            monitoring: {
                enabled: true,
                metricsInterval: 60000,
                healthCheck: {
                    enabled: true,
                    interval: 30000
                }
            },
            security: {
                validateInputs: true,
                sanitizeOutputs: true,
                rateLimiting: {
                    enabled: true,
                    maxRequests: 100,
                    windowMs: 60000
                }
            }
        };

        return this.deepMerge(defaultConfig, userConfig || {});
    }

    /**
     * Deep merge configuration objects
     */
    private deepMerge(target: any, source: any): any {
        const result = { ...target };
        for (const key in source) {
            if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
                result[key] = this.deepMerge(target[key] || {}, source[key]);
            } else {
                result[key] = source[key];
            }
        }
        return result;
    }

    /**
     * Initialize MCP server with Microsoft best practices
     */
    private initializeServer(): Server {
        return new Server(
            {
                name: this.config.server.name,
                version: this.config.server.version,
            },
            {
                capabilities: {
                    tools: { listChanged: true },
                    logging: {},
                    prompts: {},
                    resources: {}
                },
            }
        );
    }

    /**
     * Initialize CBD engine with performance optimization
     */
    private initializeCBDEngine(): CBDMemoryEngineType {
        return new CBDMemoryEngine({
            storage: {
                type: 'cbd-native',
                dataPath: this.config.cbd.dataPath
            },
            embedding: {
                model: this.config.cbd.embeddingModel,
                apiKey: this.config.cbd.apiKey,
                modelName: 'text-embedding-ada-002',
                dimensions: this.config.cbd.dimensions
            },
            vector: {
                indexType: 'faiss',
                dimensions: this.config.cbd.dimensions,
                similarityMetric: 'cosine'
            },
            cache: {
                enabled: true,
                maxSize: this.config.cbd.cacheSize,
                ttl: 3600000
            }
        });
    }

    /**
     * Setup comprehensive MCP request handlers
     */
    private setupRequestHandlers(): void {
        // List available tools with comprehensive metadata
        this.server.setRequestHandler(ListToolsRequestSchema, async () => {
            this.log('debug', 'Tools list requested');
            return { tools: this.advancedTools };
        });

        // Handle tool calls with comprehensive validation and error handling
        this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
            const startTime = Date.now();
            const requestId = uuidv4();
            
            try {
                this.log('info', `Tool call: ${request.params.name} (ID: ${requestId})`);
                
                // Validate request
                this.validateToolRequest(request);
                
                // Execute tool with performance tracking
                const result = await this.executeToolWithMetrics(
                    request.params.name,
                    request.params.arguments || {},
                    requestId,
                    startTime
                );

                this.operationCount++;
                return result;

            } catch (error: any) {
                this.log('error', `Tool execution failed: ${error.message} (ID: ${requestId})`);
                return this.createErrorResult(error, requestId, startTime);
            }
        });
    }

    /**
     * Validate tool request against schema
     */
    private validateToolRequest(request: any): void {
        if (!this.config.security.validateInputs) return;

        const tool = this.advancedTools.find(t => t.name === request.params.name);
        if (!tool) {
            throw new McpError(ErrorCode.MethodNotFound, `Tool '${request.params.name}' not found`);
        }

        // Additional validation logic could be added here
    }

    /**
     * Execute tool with comprehensive metrics and error handling
     */
    private async executeToolWithMetrics(
        toolName: string,
        args: any,
        requestId: string,
        startTime: number
    ): Promise<CallToolResult> {
        await this.ensureInitialized();

        // Map tool names to handler methods
        const toolHandlers: Record<string, (args: any, requestId: string) => Promise<AdvancedOperationResult>> = {
            // Core Memory Operations
            'remember': this.handleRemember.bind(this),
            'recall': this.handleRecall.bind(this),
            'forget': this.handleForget.bind(this),
            'context': this.handleContext.bind(this),
            
            // Intelligence & Analysis
            'analyze_patterns': this.handleAnalyzePatterns.bind(this),
            'memory_graph': this.handleMemoryGraph.bind(this),
            'temporal_search': this.handleTemporalSearch.bind(this),
            'semantic_clustering': this.handleSemanticClustering.bind(this),
            
            // Collaboration & Sharing
            'collaborative_memory': this.handleCollaborativeMemory.bind(this),
            'cross_reference': this.handleCrossReference.bind(this),
            'memory_insights': this.handleMemoryInsights.bind(this),
            
            // Management & Maintenance
            'memory_analytics': this.handleMemoryAnalytics.bind(this),
            'smart_suggestions': this.handleSmartSuggestions.bind(this),
            'memory_backup': this.handleMemoryBackup.bind(this),
            'memory_cleanup': this.handleMemoryCleanup.bind(this),
            
            // Enterprise Features
            'memory_security': this.handleMemorySecurity.bind(this),
            'memory_monitoring': this.handleMemoryMonitoring.bind(this)
        };

        const handler = toolHandlers[toolName];
        if (!handler) {
            throw new McpError(ErrorCode.MethodNotFound, `Tool '${toolName}' not implemented`);
        }

        const result = await handler(args, requestId);
        const responseTime = Date.now() - startTime;

        // Update metrics
        this.requestMetrics.set(toolName, (this.requestMetrics.get(toolName) || 0) + 1);

        return {
            content: [
                {
                    type: 'text',
                    text: JSON.stringify({
                        ...result,
                        metadata: {
                            ...result.metadata,
                            responseTimeMs: responseTime
                        }
                    }, null, 2)
                }
            ]
        };
    }

    /**
     * Create standardized error result
     */
    private createErrorResult(error: any, requestId: string, startTime: number): CallToolResult {
        const errorResult: AdvancedOperationResult = {
            success: false,
            error: error.message || 'Unknown error occurred',
            metadata: {
                operation: 'error',
                timestamp: new Date().toISOString(),
                responseTimeMs: Date.now() - startTime,
                serverVersion: this.config.server.version,
                requestId
            }
        };

        return {
            content: [
                {
                    type: 'text',
                    text: JSON.stringify(errorResult, null, 2)
                }
            ]
        };
    }

    // Core Memory Operations Implementation
    private async handleRemember(args: any, requestId: string): Promise<AdvancedOperationResult> {
        try {
            const { agentId, content, metadata = {} } = args;
            
            const memoryKey = await this.cbdEngine.store_memory(
                content,
                `Stored by agent ${agentId}`,
                {
                    projectName: metadata.project || 'default',
                    sessionName: metadata.session || 'default',
                    agentId,
                    ...metadata,
                    requestId,
                    timestamp: new Date().toISOString()
                }
            );

            return {
                success: true,
                data: {
                    memoryKey,
                    structuredKey: memoryKey,
                    agentId,
                    stored: true,
                    metadata
                },
                metadata: {
                    operation: 'remember',
                    timestamp: new Date().toISOString(),
                    responseTimeMs: 0, // Will be set by caller
                    serverVersion: this.config.server.version,
                    requestId
                }
            };

        } catch (error: any) {
            throw new McpError(ErrorCode.InternalError, `Memory storage failed: ${error.message}`);
        }
    }

    private async handleRecall(args: any, requestId: string): Promise<AdvancedOperationResult> {
        try {
            const { agentId, query, limit = 10, minImportance = 0, filters = {} } = args;
            
            const searchResult = await this.cbdEngine.search_memory(query, limit);
            
            // Filter by agent if not 'all'
            let memories = searchResult.memories;
            if (agentId !== 'all') {
                memories = memories.filter(result => result.memory.agentId === agentId);
            }

            // Apply additional filters
            if (filters.project) {
                memories = memories.filter(result => result.memory.projectName === filters.project);
            }
            if (filters.session) {
                memories = memories.filter(result => result.memory.sessionName === filters.session);
            }

            return {
                success: true,
                data: {
                    query,
                    totalFound: memories.length,
                    memories: memories.map(result => ({
                        structuredKey: result.memory.structuredKey,
                        content: result.memory.userRequest,
                        relevanceScore: result.relevanceScore,
                        timestamp: result.memory.createdAt,
                        metadata: result.memory.metadata
                    }))
                },
                metadata: {
                    operation: 'recall',
                    timestamp: new Date().toISOString(),
                    responseTimeMs: 0,
                    serverVersion: this.config.server.version,
                    requestId
                }
            };

        } catch (error: any) {
            throw new McpError(ErrorCode.InternalError, `Memory recall failed: ${error.message}`);
        }
    }

    private async handleForget(args: any, requestId: string): Promise<AdvancedOperationResult> {
        try {
            const { agentId, structuredKey, cascade = false } = args;
            
            const deleted = await this.cbdEngine.delete_memory(structuredKey);

            return {
                success: true,
                data: {
                    structuredKey,
                    deleted,
                    cascade
                },
                metadata: {
                    operation: 'forget',
                    timestamp: new Date().toISOString(),
                    responseTimeMs: 0,
                    serverVersion: this.config.server.version,
                    requestId
                }
            };

        } catch (error: any) {
            throw new McpError(ErrorCode.InternalError, `Memory deletion failed: ${error.message}`);
        }
    }

    private async handleContext(args: any, requestId: string): Promise<AdvancedOperationResult> {
        try {
            const { agentId, contextSize = 5, synthesize = true } = args;
            
            // Get recent memories for the agent
            const searchQuery = `agent:${agentId}`;
            const searchResult = await this.cbdEngine.search_memory(searchQuery, contextSize * 2);
            
            const recentMemories = searchResult.memories
                .filter(result => result.memory.agentId === agentId)
                .sort((a, b) => new Date(b.memory.createdAt).getTime() - new Date(a.memory.createdAt).getTime())
                .slice(0, contextSize);

            let contextSummary = '';
            if (synthesize && recentMemories.length > 0) {
                contextSummary = `Recent context for ${agentId}: ${recentMemories.length} memories spanning ${this.getTimeSpan(recentMemories)}`;
            }

            return {
                success: true,
                data: {
                    agentId,
                    contextSize: recentMemories.length,
                    contextSummary,
                    memories: recentMemories.map(result => ({
                        structuredKey: result.memory.structuredKey,
                        content: result.memory.userRequest,
                        timestamp: result.memory.createdAt,
                        relevanceScore: result.relevanceScore
                    }))
                },
                metadata: {
                    operation: 'context',
                    timestamp: new Date().toISOString(),
                    responseTimeMs: 0,
                    serverVersion: this.config.server.version,
                    requestId
                }
            };

        } catch (error: any) {
            throw new McpError(ErrorCode.InternalError, `Context retrieval failed: ${error.message}`);
        }
    }

    // Intelligence & Analysis Operations (placeholder implementations)
    private async handleAnalyzePatterns(args: any, requestId: string): Promise<AdvancedOperationResult> {
        return this.createPlaceholderResult('analyze_patterns', 'Pattern analysis completed', requestId);
    }

    private async handleMemoryGraph(args: any, requestId: string): Promise<AdvancedOperationResult> {
        return this.createPlaceholderResult('memory_graph', 'Memory graph generated', requestId);
    }

    private async handleTemporalSearch(args: any, requestId: string): Promise<AdvancedOperationResult> {
        return this.createPlaceholderResult('temporal_search', 'Temporal search completed', requestId);
    }

    private async handleSemanticClustering(args: any, requestId: string): Promise<AdvancedOperationResult> {
        return this.createPlaceholderResult('semantic_clustering', 'Semantic clustering completed', requestId);
    }

    // Collaboration & Sharing Operations (placeholder implementations)
    private async handleCollaborativeMemory(args: any, requestId: string): Promise<AdvancedOperationResult> {
        return this.createPlaceholderResult('collaborative_memory', 'Memory shared successfully', requestId);
    }

    private async handleCrossReference(args: any, requestId: string): Promise<AdvancedOperationResult> {
        return this.createPlaceholderResult('cross_reference', 'Cross-references found', requestId);
    }

    private async handleMemoryInsights(args: any, requestId: string): Promise<AdvancedOperationResult> {
        return this.createPlaceholderResult('memory_insights', 'Insights generated', requestId);
    }

    // Management & Maintenance Operations (placeholder implementations)
    private async handleMemoryAnalytics(args: any, requestId: string): Promise<AdvancedOperationResult> {
        return this.createPlaceholderResult('memory_analytics', 'Analytics report generated', requestId);
    }

    private async handleSmartSuggestions(args: any, requestId: string): Promise<AdvancedOperationResult> {
        return this.createPlaceholderResult('smart_suggestions', 'Smart suggestions provided', requestId);
    }

    private async handleMemoryBackup(args: any, requestId: string): Promise<AdvancedOperationResult> {
        return this.createPlaceholderResult('memory_backup', 'Backup operation completed', requestId);
    }

    private async handleMemoryCleanup(args: any, requestId: string): Promise<AdvancedOperationResult> {
        return this.createPlaceholderResult('memory_cleanup', 'Cleanup completed', requestId);
    }

    // Enterprise Features (placeholder implementations)
    private async handleMemorySecurity(args: any, requestId: string): Promise<AdvancedOperationResult> {
        return this.createPlaceholderResult('memory_security', 'Security check completed', requestId);
    }

    private async handleMemoryMonitoring(args: any, requestId: string): Promise<AdvancedOperationResult> {
        const uptime = Date.now() - this.startTime;
        const memUsage = process.memoryUsage();
        
        return {
            success: true,
            data: {
                status: 'healthy',
                uptime: Math.floor(uptime / 1000),
                operationCount: this.operationCount,
                memoryUsage: {
                    rss: memUsage.rss,
                    heapTotal: memUsage.heapTotal,
                    heapUsed: memUsage.heapUsed,
                    external: memUsage.external
                },
                serverInfo: {
                    name: this.config.server.name,
                    version: this.config.server.version,
                    transport: this.config.transport.primary
                }
            },
            metadata: {
                operation: 'memory_monitoring',
                timestamp: new Date().toISOString(),
                responseTimeMs: 0,
                serverVersion: this.config.server.version,
                requestId
            }
        };
    }

    /**
     * Create placeholder result for unimplemented features
     */
    private createPlaceholderResult(operation: string, message: string, requestId: string): AdvancedOperationResult {
        return {
            success: true,
            data: {
                message,
                note: 'This feature will be fully implemented in subsequent phases'
            },
            metadata: {
                operation,
                timestamp: new Date().toISOString(),
                responseTimeMs: 0,
                serverVersion: this.config.server.version,
                requestId
            }
        };
    }

    /**
     * Calculate time span for context memories
     */
    private getTimeSpan(memories: any[]): string {
        if (memories.length === 0) return 'no time range';
        
        const dates = memories.map(m => new Date(m.memory.createdAt));
        const oldest = new Date(Math.min(...dates.map(d => d.getTime())));
        const newest = new Date(Math.max(...dates.map(d => d.getTime())));
        
        const diffMs = newest.getTime() - oldest.getTime();
        const hours = Math.floor(diffMs / (1000 * 60 * 60));
        
        if (hours < 1) return 'within the last hour';
        if (hours < 24) return `${hours} hours`;
        const days = Math.floor(hours / 24);
        return `${days} days`;
    }

    /**
     * Initialize monitoring and health checks
     */
    private initializeMonitoring(): void {
        if (!this.config.monitoring.enabled) return;

        // Health check interval
        if (this.config.monitoring.healthCheck.enabled) {
            setInterval(() => {
                this.performHealthCheck();
            }, this.config.monitoring.healthCheck.interval);
        }

        // Metrics collection interval
        setInterval(() => {
            this.collectMetrics();
        }, this.config.monitoring.metricsInterval);
    }

    /**
     * Perform health check
     */
    private performHealthCheck(): void {
        try {
            const memUsage = process.memoryUsage();
            const uptime = Date.now() - this.startTime;
            
            this.log('debug', `Health Check - Uptime: ${Math.floor(uptime / 1000)}s, Operations: ${this.operationCount}, Memory: ${Math.floor(memUsage.heapUsed / 1024 / 1024)}MB`);
        } catch (error: any) {
            this.log('error', `Health check failed: ${error.message}`);
        }
    }

    /**
     * Collect performance metrics
     */
    private collectMetrics(): void {
        try {
            const metrics = {
                timestamp: new Date().toISOString(),
                uptime: Date.now() - this.startTime,
                operationCount: this.operationCount,
                requestMetrics: Object.fromEntries(this.requestMetrics),
                memoryUsage: process.memoryUsage(),
                serverInfo: {
                    name: this.config.server.name,
                    version: this.config.server.version
                }
            };

            this.log('debug', `Metrics collected: ${JSON.stringify(metrics)}`);
        } catch (error: any) {
            this.log('error', `Metrics collection failed: ${error.message}`);
        }
    }

    /**
     * Ensure CBD engine is initialized
     */
    private async ensureInitialized(): Promise<void> {
        if (!this.initialized) {
            await this.cbdEngine.initialize();
            this.initialized = true;
            this.log('info', `${this.config.server.name} v${this.config.server.version} initialized successfully`);
        }
    }

    /**
     * Enhanced logging with structured output
     */
    private log(level: string, message: string, meta?: any): void {
        if (!this.config.logging.enabled) return;

        const logEntry = this.config.logging.structured
            ? {
                timestamp: new Date().toISOString(),
                level: level.toUpperCase(),
                service: this.config.server.name,
                version: this.config.server.version,
                message,
                ...meta
            }
            : `[${new Date().toISOString()}] [${level.toUpperCase()}] ${message}`;

        if (this.config.logging.output === 'console' || this.config.logging.output === 'both') {
            console.error(typeof logEntry === 'object' ? JSON.stringify(logEntry) : logEntry);
        }

        // File logging would be implemented here if needed
    }

    /**
     * Start the advanced MCP server with multi-transport support
     */
    async start(): Promise<void> {
        try {
            await this.ensureInitialized();

            if (this.config.transport.primary === 'stdio') {
                await this.startStdioTransport();
            } else if (this.config.transport.primary === 'http') {
                await this.startHttpTransport();
            }

            this.log('info', `🚀 ${this.config.server.name} v${this.config.server.version} started successfully`);
            this.log('info', `Primary transport: ${this.config.transport.primary}`);
            this.log('info', `Available tools: ${this.advancedTools.length}`);

        } catch (error: any) {
            this.log('error', `Failed to start server: ${error.message}`);
            throw error;
        }
    }

    /**
     * Start stdio transport
     */
    private async startStdioTransport(): Promise<void> {
        const transport = new StdioServerTransport();
        await this.server.connect(transport);
        this.log('info', '📡 Stdio transport connected');
    }

    /**
     * Start HTTP transport with comprehensive API
     */
    private async startHttpTransport(): Promise<void> {
        if (!this.config.transport.http) {
            throw new Error('HTTP transport configuration missing');
        }

        this.expressApp = express();
        this.httpServer = createServer(this.expressApp);

        // Middleware
        this.expressApp.use(cors(this.config.transport.http.cors));
        this.expressApp.use(express.json({ limit: '10mb' }));
        this.expressApp.use(express.urlencoded({ extended: true }));

        // Authentication middleware
        const authenticate = (req: any, res: any, next: any) => {
            const authHeader = req.headers.authorization;
            const apiKey = authHeader?.replace('Bearer ', '') ||
                req.query.apiKey ||
                req.headers['x-api-key'];

            if (!apiKey || apiKey !== this.config.transport.http!.apiKey) {
                return res.status(401).json({
                    error: 'Authentication required',
                    message: 'Please provide a valid API key'
                });
            }
            next();
        };

        // Health check endpoint (no auth required)
        this.expressApp.get('/health', (req, res) => {
            const uptime = Date.now() - this.startTime;
            res.json({
                status: 'healthy',
                service: this.config.server.name,
                version: this.config.server.version,
                uptime: Math.floor(uptime / 1000),
                operationCount: this.operationCount,
                timestamp: new Date().toISOString()
            });
        });

        // MCP protocol endpoints
        this.expressApp.get('/', (req, res) => {
            res.json({
                jsonrpc: "2.0",
                result: {
                    protocolVersion: "2025-06-18",
                    capabilities: {
                        tools: { listChanged: true },
                        logging: {}
                    },
                    serverInfo: {
                        name: this.config.server.name,
                        version: this.config.server.version
                    }
                }
            });
        });

        this.expressApp.post('/', authenticate, (req, res) => {
            // Handle MCP requests over HTTP
            // This would need full MCP protocol implementation
            res.json({
                jsonrpc: "2.0",
                id: req.body.id,
                result: {
                    message: 'HTTP transport implementation in progress'
                }
            });
        });

        // Start HTTP server
        await new Promise<void>((resolve, reject) => {
            this.httpServer!.listen(this.config.transport.http!.port, this.config.transport.http!.host, (err?: any) => {
                if (err) reject(err);
                else {
                    this.log('info', `🌐 HTTP server listening on ${this.config.transport.http!.host}:${this.config.transport.http!.port}`);
                    resolve();
                }
            });
        });
    }

    /**
     * Stop the server gracefully
     */
    async stop(): Promise<void> {
        try {
            if (this.httpServer) {
                await new Promise<void>((resolve) => {
                    this.httpServer!.close(() => resolve());
                });
            }

            if (this.initialized) {
                await this.cbdEngine.shutdown();
            }

            this.log('info', '🛑 MemorAI Advanced MCP Server stopped gracefully');
        } catch (error: any) {
            this.log('error', `Error during shutdown: ${error.message}`);
        }
    }
}

// CLI entry point
if (import.meta.url === `file://${process.argv[1]}`) {
    const server = new AdvancedMemorAIMCPServer();
    
    process.on('SIGINT', async () => {
        console.log('\nShutdown signal received, stopping server...');
        await server.stop();
        process.exit(0);
    });

    server.start().catch(error => {
        console.error('Failed to start server:', error);
        process.exit(1);
    });
}

export default AdvancedMemorAIMCPServer;
