#!/usr/bin/env node

/**
 * MemorAI MCP Server - VS Code Compatible
 * Proper MCP Protocol Implementation for VS Code Integration
 * Date: August 4, 2025
 * Port: 4950
 */

const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.MEMORAI_MCP_PORT || 4950;
const API_KEY = process.env.MEMORAI_API_KEY || 'memorai-dev-key-2025';

// Enable CORS for VS Code
app.use(cors({
    origin: '*',
    credentials: true,
    methods: ['GET', 'POST', 'OPTIONS'],
    headers: ['Content-Type', 'Authorization', 'x-api-key']
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// In-memory storage
let memories = [];
let memoryCounter = 1;

// Authentication middleware
const authenticate = (req, res, next) => {
    const authHeader = req.headers.authorization;
    const apiKey = authHeader?.replace('Bearer ', '') ||
        req.query.apiKey ||
        req.headers['x-api-key'];

    if (!apiKey || apiKey !== API_KEY) {
        return res.status(401).json({
            error: 'Authentication required',
            message: 'Please provide a valid API key'
        });
    }
    next();
};

// MCP Protocol Implementation

// Root endpoint for VS Code MCP client
app.get('/', (req, res) => {
    res.json({
        jsonrpc: "2.0",
        result: {
            protocolVersion: "2025-06-18",
            capabilities: {
                tools: { listChanged: true },
                logging: {}
            },
            serverInfo: {
                name: "memorai-mcp",
                version: "1.0.0"
            }
        }
    });
});

// MCP Initialize endpoint
app.post('/', (req, res) => {
    const { method, params, id } = req.body;

    if (method === 'initialize') {
        res.json({
            jsonrpc: "2.0",
            id: id,
            result: {
                protocolVersion: "2025-06-18",
                capabilities: {
                    tools: { listChanged: true },
                    logging: {}
                },
                serverInfo: {
                    name: "memorai-mcp",
                    version: "1.0.0"
                }
            }
        });
        return;
    }

    if (method === 'tools/list') {
        res.json({
            jsonrpc: "2.0",
            id: id,
            result: {
                tools: [
                    {
                        name: "remember",
                        description: "Store a memory with content and metadata",
                        inputSchema: {
                            type: "object",
                            properties: {
                                agentId: {
                                    type: "string",
                                    description: "Agent identifier for memory isolation"
                                },
                                content: {
                                    type: "string",
                                    description: "The content to remember"
                                },
                                metadata: {
                                    type: "object",
                                    description: "Additional metadata for the memory",
                                    properties: {
                                        entityType: { type: "string" },
                                        priority: { type: "string" },
                                        project: { type: "string" },
                                        session: { type: "string" },
                                        tags: {
                                            type: "array",
                                            items: { type: "string" }
                                        }
                                    }
                                }
                            },
                            required: ["agentId", "content"]
                        }
                    },
                    {
                        name: "recall",
                        description: "Search and retrieve memories with intelligent suggestions",
                        inputSchema: {
                            type: "object",
                            properties: {
                                agentId: {
                                    type: "string",
                                    description: "Agent identifier for memory isolation"
                                },
                                query: {
                                    type: "string",
                                    description: "Search query for finding relevant memories"
                                },
                                limit: {
                                    type: "number",
                                    description: "Maximum number of results to return (default: 10)",
                                    default: 10
                                },
                                minImportance: {
                                    type: "number",
                                    description: "Minimum importance score filter (default: 0)",
                                    default: 0
                                },
                                project: {
                                    type: "string",
                                    description: "Filter memories by project name"
                                },
                                session: {
                                    type: "string",
                                    description: "Filter memories by session identifier"
                                }
                            },
                            required: ["agentId", "query"]
                        }
                    },
                    {
                        name: "forget",
                        description: "Delete a memory by structured key",
                        inputSchema: {
                            type: "object",
                            properties: {
                                agentId: {
                                    type: "string",
                                    description: "Agent identifier"
                                },
                                structuredKey: {
                                    type: "string",
                                    description: "Structured key of memory to delete"
                                }
                            },
                            required: ["agentId", "structuredKey"]
                        }
                    },
                    {
                        name: "context",
                        description: "Get recent context for agent",
                        inputSchema: {
                            type: "object",
                            properties: {
                                agentId: {
                                    type: "string",
                                    description: "Agent identifier"
                                },
                                contextSize: {
                                    type: "number",
                                    description: "Number of recent memories to retrieve (default: 5)",
                                    default: 5
                                }
                            },
                            required: ["agentId"]
                        }
                    }
                ]
            }
        });
        return;
    }

    if (method === 'tools/call') {
        const { name, arguments: args } = params;
        const toolId = uuidv4();

        try {
            switch (name) {
                case 'remember':
                    const memory = {
                        id: `mem_${memoryCounter++}`,
                        agentId: args.agentId,
                        content: args.content,
                        metadata: args.metadata || {},
                        timestamp: new Date().toISOString(),
                        lastAccessed: new Date().toISOString(),
                        structuredKey: `${args.agentId}_${Date.now()}_${memoryCounter}`
                    };
                    memories.push(memory);

                    res.json({
                        jsonrpc: "2.0",
                        id: id,
                        result: {
                            content: [{
                                type: "text",
                                text: `✅ Memory stored successfully!\n\nID: ${memory.id}\nAgent: ${memory.agentId}\nContent: ${memory.content}\nStructured Key: ${memory.structuredKey}\nTimestamp: ${memory.timestamp}`
                            }],
                            isError: false
                        }
                    });
                    break;

                case 'recall':
                    const query = args.query.toLowerCase();
                    const limit = args.limit || 10;
                    const minImportance = args.minImportance || 0;
                    const agentId = args.agentId;

                    let matchingMemories = memories.filter(memory => {
                        if (memory.agentId !== agentId) return false;

                        const contentMatch = memory.content.toLowerCase().includes(query);
                        const importance = memory.metadata.importance || 5;
                        const projectMatch = !args.project || memory.metadata.project === args.project;
                        const sessionMatch = !args.session || memory.metadata.session === args.session;

                        return contentMatch && importance >= minImportance && projectMatch && sessionMatch;
                    });

                    matchingMemories = matchingMemories
                        .sort((a, b) => {
                            const aImportance = a.metadata.importance || 5;
                            const bImportance = b.metadata.importance || 5;
                            return bImportance - aImportance;
                        })
                        .slice(0, limit);

                    // Update last accessed time
                    matchingMemories.forEach(memory => {
                        memory.lastAccessed = new Date().toISOString();
                    });

                    const resultsText = matchingMemories.length > 0
                        ? `🔍 Found ${matchingMemories.length} matching memories for agent "${agentId}":\n\n` +
                        matchingMemories.map((memory, index) =>
                            `${index + 1}. **${memory.structuredKey}**\n` +
                            `   Content: ${memory.content}\n` +
                            `   Importance: ${memory.metadata.importance || 5}/10\n` +
                            `   Project: ${memory.metadata.project || 'N/A'}\n` +
                            `   Tags: ${memory.metadata.tags ? memory.metadata.tags.join(', ') : 'None'}\n` +
                            `   Created: ${memory.timestamp}\n`
                        ).join('\n')
                        : `🔍 No memories found for query "${query}" (agent: ${agentId})`;

                    res.json({
                        jsonrpc: "2.0",
                        id: id,
                        result: {
                            content: [{
                                type: "text",
                                text: resultsText
                            }],
                            isError: false
                        }
                    });
                    break;

                case 'forget':
                    const structuredKey = args.structuredKey;
                    const agentForget = args.agentId;
                    const memoryIndex = memories.findIndex(m =>
                        m.structuredKey === structuredKey && m.agentId === agentForget
                    );

                    if (memoryIndex === -1) {
                        res.json({
                            jsonrpc: "2.0",
                            id: id,
                            result: {
                                content: [{
                                    type: "text",
                                    text: `❌ Memory with structured key "${structuredKey}" not found for agent "${agentForget}"`
                                }],
                                isError: true
                            }
                        });
                    } else {
                        const deletedMemory = memories.splice(memoryIndex, 1)[0];
                        res.json({
                            jsonrpc: "2.0",
                            id: id,
                            result: {
                                content: [{
                                    type: "text",
                                    text: `✅ Memory deleted successfully!\n\nDeleted: ${deletedMemory.structuredKey}\nContent: ${deletedMemory.content}\nAgent: ${deletedMemory.agentId}`
                                }],
                                isError: false
                            }
                        });
                    }
                    break;

                case 'context':
                    const contextAgent = args.agentId;
                    const contextSize = args.contextSize || 5;
                    const recentMemories = memories
                        .filter(m => m.agentId === contextAgent)
                        .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
                        .slice(0, contextSize);

                    const contextText = recentMemories.length > 0
                        ? `📝 Recent context for agent "${contextAgent}" (${recentMemories.length} memories):\n\n` +
                        recentMemories.map((memory, index) =>
                            `${index + 1}. [${memory.timestamp}] ${memory.content.substring(0, 100)}${memory.content.length > 100 ? '...' : ''}\n` +
                            `   Project: ${memory.metadata.project || 'N/A'}\n` +
                            `   Key: ${memory.structuredKey}\n`
                        ).join('\n')
                        : `📝 No recent context found for agent "${contextAgent}"`;

                    res.json({
                        jsonrpc: "2.0",
                        id: id,
                        result: {
                            content: [{
                                type: "text",
                                text: contextText
                            }],
                            isError: false
                        }
                    });
                    break;

                default:
                    res.json({
                        jsonrpc: "2.0",
                        id: id,
                        error: {
                            code: -32601,
                            message: `Unknown tool: ${name}`
                        }
                    });
            }
        } catch (error) {
            console.error('Tool execution error:', error);
            res.json({
                jsonrpc: "2.0",
                id: id,
                error: {
                    code: -32603,
                    message: `Error executing tool ${name}: ${error.message}`
                }
            });
        }
        return;
    }

    // Unknown method
    res.json({
        jsonrpc: "2.0",
        id: id,
        error: {
            code: -32601,
            message: `Unknown method: ${method}`
        }
    });
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({
        status: 'healthy',
        service: 'MemorAI MCP Server',
        version: '1.0.0',
        port: PORT,
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        environment: process.env.NODE_ENV || 'development',
        totalMemories: memories.length,
        mcpProtocol: '2025-06-18'
    });
});

// Stats endpoint
app.get('/stats', authenticate, (req, res) => {
    const agentStats = memories.reduce((acc, memory) => {
        acc[memory.agentId] = (acc[memory.agentId] || 0) + 1;
        return acc;
    }, {});

    res.json({
        totalMemories: memories.length,
        memoriesByAgent: agentStats,
        serverInfo: {
            name: 'MemorAI MCP Server',
            version: '1.0.0',
            port: PORT,
            uptime: process.uptime(),
            protocol: '2025-06-18'
        },
        timestamp: new Date().toISOString()
    });
});

// Error handling
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).json({
        jsonrpc: "2.0",
        error: {
            code: -32603,
            message: 'Internal server error'
        }
    });
});

// Start server
const server = app.listen(PORT, () => {
    console.log(`🧠 MemorAI MCP Server (VS Code Compatible) started successfully!`);
    console.log(`📡 Server running on http://localhost:${PORT}`);
    console.log(`🔑 API Key: ${API_KEY}`);
    console.log(`📅 Date: ${new Date().toISOString()}`);
    console.log(`🎯 MCP Protocol: 2025-06-18 (VS Code Compatible)`);
    console.log(`✅ Ready for VS Code MCP integration`);
    console.log(`🔧 Root endpoint: GET/POST http://localhost:${PORT}/`);
    console.log(`💡 Health check: GET http://localhost:${PORT}/health`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    server.close(() => {
        console.log('MemorAI MCP Server closed');
        process.exit(0);
    });
});

process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully');
    server.close(() => {
        console.log('MemorAI MCP Server closed');
        process.exit(0);
    });
});
